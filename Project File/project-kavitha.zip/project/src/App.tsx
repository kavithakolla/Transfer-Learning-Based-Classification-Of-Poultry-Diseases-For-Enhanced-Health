import React, { useState } from 'react';
import { Upload, AlertCircle, CheckCircle, Stethoscope, Users, BookOpen, ArrowRight, Camera, FileImage, Loader } from 'lucide-react';

// Disease data with treatment recommendations
const diseaseData = {
  salmonella: {
    name: 'Salmonella',
    severity: 'High Risk',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    description: 'Bacterial infection causing digestive issues and reduced productivity.',
    symptoms: ['Diarrhea', 'Lethargy', 'Reduced appetite', 'Dehydration'],
    treatment: [
      'Isolate affected birds immediately',
      'Administer antibiotics as prescribed by veterinarian',
      'Provide electrolyte solutions',
      'Improve sanitation and hygiene practices',
      'Monitor flock closely for 2-3 weeks'
    ],
    prevention: [
      'Regular cleaning and disinfection',
      'Proper feed storage',
      'Clean water supply',
      'Quarantine new birds'
    ]
  },
  newcastle: {
    name: 'Newcastle Disease',
    severity: 'Critical',
    color: 'text-red-700',
    bgColor: 'bg-red-100',
    borderColor: 'border-red-300',
    description: 'Highly contagious viral disease affecting respiratory and nervous systems.',
    symptoms: ['Respiratory distress', 'Nervous signs', 'Drop in egg production', 'Sudden death'],
    treatment: [
      'No specific treatment - supportive care only',
      'Immediate quarantine of entire flock',
      'Contact veterinary authorities immediately',
      'Vaccination of healthy birds',
      'Strict biosecurity measures'
    ],
    prevention: [
      'Regular vaccination schedule',
      'Strict biosecurity protocols',
      'Limit visitor access',
      'Proper disposal of dead birds'
    ]
  },
  coccidiosis: {
    name: 'Coccidiosis',
    severity: 'Moderate',
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200',
    description: 'Parasitic infection affecting the intestinal tract, common in young birds.',
    symptoms: ['Bloody diarrhea', 'Weight loss', 'Pale combs', 'Reduced growth'],
    treatment: [
      'Administer coccidiostats as directed',
      'Provide vitamin K supplements',
      'Improve ventilation and reduce moisture',
      'Remove wet litter immediately',
      'Monitor feed conversion rates'
    ],
    prevention: [
      'Use medicated starter feeds',
      'Maintain dry, clean litter',
      'Proper stocking density',
      'Regular litter management'
    ]
  },
  healthy: {
    name: 'Healthy',
    severity: 'Good Health',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    description: 'Birds appear healthy with no signs of disease.',
    symptoms: ['Active behavior', 'Good appetite', 'Normal egg production', 'Bright eyes'],
    treatment: [
      'Continue current management practices',
      'Maintain regular health monitoring',
      'Keep vaccination schedule up to date',
      'Monitor for any changes in behavior'
    ],
    prevention: [
      'Regular health checks',
      'Proper nutrition program',
      'Clean environment maintenance',
      'Stress reduction measures'
    ]
  }
};

function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'upload' | 'results'>('landing');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [diagnosis, setDiagnosis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleImageUpload = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageUpload(e.dataTransfer.files[0]);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;
    
    setIsAnalyzing(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Simulate disease detection (in real app, this would be ML model prediction)
    const diseases = ['salmonella', 'newcastle', 'coccidiosis', 'healthy'];
    const randomDiagnosis = diseases[Math.floor(Math.random() * diseases.length)];
    
    setDiagnosis(randomDiagnosis);
    setIsAnalyzing(false);
    setCurrentView('results');
  };

  const resetApp = () => {
    setCurrentView('landing');
    setSelectedImage(null);
    setImagePreview(null);
    setDiagnosis(null);
    setIsAnalyzing(false);
  };

  if (currentView === 'landing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
        {/* Header */}
        <nav className="bg-white shadow-sm border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <Stethoscope className="h-8 w-8 text-green-600" />
                <span className="text-xl font-bold text-gray-800">PoultryHealthAI</span>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600">Powered by Deep Learning</span>
              </div>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Advanced Poultry
              <span className="text-green-600 block">Disease Classification</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Empowering farmers with AI-powered disease detection. Upload an image of your poultry 
              and receive instant diagnosis with professional treatment recommendations.
            </p>
            <button
              onClick={() => setCurrentView('upload')}
              className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <Camera className="h-5 w-5" />
              <span>Get Started</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-8 mt-20">
            <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
              <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <AlertCircle className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Instant Diagnosis</h3>
              <p className="text-gray-600 leading-relaxed">
                Get immediate results for Salmonella, Newcastle Disease, Coccidiosis, or confirm healthy birds using our trained AI model.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
              <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Treatment Guidance</h3>
              <p className="text-gray-600 leading-relaxed">
                Receive detailed treatment recommendations and management practices tailored to each specific diagnosis.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
              <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">For All Farmers</h3>
              <p className="text-gray-600 leading-relaxed">
                Designed for rural communities, commercial farms, and veterinary education with an intuitive mobile-friendly interface.
              </p>
            </div>
          </div>

          {/* Use Cases */}
          <div className="mt-20">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Real-World Applications</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-8 text-white">
                <h3 className="text-2xl font-bold mb-4">Rural Community Support</h3>
                <p className="text-green-100 leading-relaxed">
                  When veterinary services are hours away, farmers can quickly identify diseases like Coccidiosis 
                  and take immediate action to prevent spread and economic losses.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-8 text-white">
                <h3 className="text-2xl font-bold mb-4">Commercial Farm Management</h3>
                <p className="text-blue-100 leading-relaxed">
                  Large operations use daily health monitoring to detect Newcastle Disease early, 
                  enabling rapid quarantine and control measures to protect entire flocks.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentView === 'upload') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <nav className="bg-white shadow-sm border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <button
                onClick={resetApp}
                className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
              >
                <Stethoscope className="h-8 w-8 text-green-600" />
                <span className="text-xl font-bold text-gray-800">PoultryHealthAI</span>
              </button>
            </div>
          </div>
        </nav>

        {/* Upload Interface */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Upload Poultry Image</h1>
            <p className="text-gray-600">Upload a clear image of your poultry for disease analysis</p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            {!imagePreview ? (
              <div
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
                  dragActive 
                    ? 'border-green-400 bg-green-50' 
                    : 'border-gray-300 hover:border-green-400 hover:bg-gray-50'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center">
                    <Upload className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Drag and drop your image here
                    </h3>
                    <p className="text-gray-500 mb-4">or click to browse files</p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => e.target.files && handleImageUpload(e.target.files[0])}
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg cursor-pointer transition-colors"
                    >
                      <FileImage className="h-5 w-5" />
                      <span>Choose File</span>
                    </label>
                  </div>
                  <p className="text-sm text-gray-400">
                    Supported formats: JPG, PNG, JPEG (Max 10MB)
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-center">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="max-w-md max-h-64 object-cover rounded-xl shadow-md"
                  />
                </div>
                
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => {
                      setSelectedImage(null);
                      setImagePreview(null);
                    }}
                    className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Choose Different Image
                  </button>
                  
                  <button
                    onClick={analyzeImage}
                    disabled={isAnalyzing}
                    className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium py-3 px-8 rounded-lg transition-colors"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader className="h-5 w-5 animate-spin" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <Stethoscope className="h-5 w-5" />
                        <span>Analyze Image</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {isAnalyzing && (
            <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
              <div className="flex items-center space-x-3">
                <Loader className="h-6 w-6 text-blue-600 animate-spin" />
                <div>
                  <h3 className="font-semibold text-blue-900">Analyzing Your Image</h3>
                  <p className="text-blue-700">Our AI model is examining the image for disease indicators...</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (currentView === 'results' && diagnosis) {
    const diseaseInfo = diseaseData[diagnosis as keyof typeof diseaseData];
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <nav className="bg-white shadow-sm border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <button
                onClick={resetApp}
                className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
              >
                <Stethoscope className="h-8 w-8 text-green-600" />
                <span className="text-xl font-bold text-gray-800">PoultryHealthAI</span>
              </button>
              <button
                onClick={resetApp}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                New Analysis
              </button>
            </div>
          </div>
        </nav>

        {/* Results */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Diagnosis Results</h1>
            <p className="text-gray-600">Analysis complete - here are your results and recommendations</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Image and Diagnosis */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Uploaded Image</h2>
              {imagePreview && (
                <img
                  src={imagePreview}
                  alt="Analyzed"
                  className="w-full h-64 object-cover rounded-xl mb-6"
                />
              )}
              
              <div className={`${diseaseInfo.bgColor} ${diseaseInfo.borderColor} border rounded-xl p-6`}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold text-gray-900">{diseaseInfo.name}</h3>
                  <span className={`${diseaseInfo.color} font-semibold`}>{diseaseInfo.severity}</span>
                </div>
                <p className="text-gray-700 mb-4">{diseaseInfo.description}</p>
                
                <div className="flex items-center space-x-2">
                  {diagnosis === 'healthy' ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-red-600" />
                  )}
                  <span className="text-sm text-gray-600">
                    {diagnosis === 'healthy' ? 'No immediate action required' : 'Immediate attention recommended'}
                  </span>
                </div>
              </div>
            </div>

            {/* Treatment Recommendations */}
            <div className="space-y-6">
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Observed Symptoms</h3>
                <ul className="space-y-2">
                  {diseaseInfo.symptoms.map((symptom, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-gray-700">{symptom}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Treatment Recommendations</h3>
                <ul className="space-y-3">
                  {diseaseInfo.treatment.map((treatment, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-semibold text-green-600">{index + 1}</span>
                      </div>
                      <span className="text-gray-700">{treatment}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Prevention Measures</h3>
                <ul className="space-y-2">
                  {diseaseInfo.prevention.map((prevention, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{prevention}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {diagnosis !== 'healthy' && (
            <div className="mt-8 bg-red-50 border border-red-200 rounded-xl p-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-900 mb-2">Important Notice</h3>
                  <p className="text-red-800">
                    This AI diagnosis is for informational purposes only. Please consult with a qualified 
                    veterinarian for professional medical advice and treatment. Early intervention is 
                    crucial for the health of your flock.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
}

export default App;